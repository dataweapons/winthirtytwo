﻿########################################################### 
# AUTHOR  : Branko Vucinec - http://blog.brankovucinec.com
# DATE    : 15-07-2015  
# COMMENT : This script will disable SSL 3.0 for all server 
#           software installed on a system, including IIS.
# VERSION : 1.0 
########################################################### 
#Requires -RunAsAdministrator

#---------------------------------------------------------- 
#VARIABLES
#---------------------------------------------------------- 
$RegPath = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\"
$RegName = "Server"
$RegItem = "Enable"
$RegValue = "0"
$RegType = "DWord"
$RegTest = Test-Path "$RegPath\$RegName"

#---------------------------------------------------------- 
#CHECK IF KEY EXISTS
#----------------------------------------------------------
function KeyCheck {
    if ($RegTest -eq $true) {
        return
    } else { 
        New-Item -Path $RegPath -ItemType File -Name $RegName -Force -ErrorAction SilentlyContinue | Out-Null
        return
    }
}

#---------------------------------------------------------- 
#SET THE DWORD VALUE
#----------------------------------------------------------
function SetRegValue {
    Set-ItemProperty -Path "$RegPath\$RegName" -Name $RegItem -Value $RegValue -Type $RegType -ErrorAction SilentlyContinue | Out-Null
    return
}

#---------------------------------------------------------- 
#START
#----------------------------------------------------------
Clear-Host
Write-Host "Running Disable-SSLv3Server.ps1 - v1.0" -ForegroundColor Green
Write-Host "This script will disable SSL 3.0 for all server software installed on a system, including IIS." -ForegroundColor DarkGreen
Write-Host "Author: Branko Vucinec - 2015-07-15" -ForegroundColor DarkGreen
KeyCheck
SetRegValue