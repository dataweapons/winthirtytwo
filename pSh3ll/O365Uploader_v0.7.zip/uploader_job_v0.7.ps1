﻿$job1VARS.ERRORCount = 0
$job1VARS.WarningCount = 0
$job1VARS.Trigger = 0
$detaillogpath = $env:temp+"\SharePointUploaderDetailedLog"+$job1VARS.iRemoteFolder+".log"
ac $detaillogpath "-----$(Get-Date) Session Detailedlog-----`n"

Function Ensure-Folder()
{
Param(
  [Parameter(Mandatory=$True)]
  [Microsoft.SharePoint.Client.Web]$Web,
 
  [Parameter(Mandatory=$True)]
  [Microsoft.SharePoint.Client.Folder]$ParentFolder, 
 
  [Parameter(Mandatory=$True)]
  [String]$FolderUrl
 
)
    $foldercheck = $True
    $folderNames = $FolderUrl.Trim().Split("/",[System.StringSplitOptions]::RemoveEmptyEntries)
    $folderName = $folderNames[0]
    if($folderName.StartsWith("_") -eq $True){
        $outstring = "WARNING| underscore first character in [$($folderName)], item will be copied normally but will be hidden in destination.`n"
        ac $verifylogpath $outstring
        $job1VARS.WarningCount++                   
    }
    if($folderName.EndsWith(".") -eq $True -or $folderName.StartsWith(".") -eq $True){
        $outstring = "ERROR| [$($FolderUrl)] will be skipped, folders or files cannot end or start with a period character.`n"
        ac $verifylogpath $outstring
        $foldercheck = $False
        $job1VARS.ERRORCount++                    
    }
    <# FOLDERNAME CORRECTION MECHANISM #>
    $badchars = ':,*,?,",<,>,|,#,{,},%,~,&'
    foreach($e in $badchars.Split(',')) { 
        if($folderName.Contains($e)){
            $folderName = $folderName.Replace($e,"")
            ac $detaillogpath "WARNING| illegal foldername [$($folderName)], $e character removed automatically`n"
            $job1VARS.WarningCount++
        }
    }
    if($foldercheck -eq $True){
        ac $detaillogpath "NOTICE| Creating folder [$folderName] ..."
        $curFolder = $ParentFolder.Folders.Add($folderName)
        $Web.Context.Load($curFolder)
        try{
            $web.Context.ExecuteQuery()
            $url_disp = $($curFolder.ServerRelativeUrl)   
            ac $detaillogpath "NOTICE| Folder [$folderName] created. Url: [$url_disp]`n"
        }catch{
            $job1VARS.ERRORCount++
            $err = $Error[0]|format-list -force
            ac $detaillogpath "ERROR| Folder [$folderName] not created at $($url_disp): $($Error[0]) `n$($err)"
        }           
            
    }
 
    if ($folderNames.Length -gt 1)
    {
        $curFolderUrl = [System.String]::Join("/", $folderNames, 1, $folderNames.Length - 1)
        Ensure-Folder -Web $Web -ParentFolder $curFolder -FolderUrl $curFolderUrl
    }
}
 
 
 
Function Upload-File() 
{
Param(
  [Parameter(Mandatory=$True)]
  [Microsoft.SharePoint.Client.Web]$Web,
 
  [Parameter(Mandatory=$True)]
  [String]$FolderRelativeUrl, 
 
  [Parameter(Mandatory=$True)]
  [System.IO.FileInfo]$LocalFile
 
)
    $filecheck = $True

    <# FILENAME CORRECTION MECHANISM #>
    $filename = $LocalFile.Name
    $badendings = @(".files","_files","-Dateien","_fichiers","_bestanden","_file","_archivos","-filer","_tiedostot","_pliki","_soubory","_elemei","_ficheiros","_arquivos","_dosyalar","_datoteke","_fitxers","_failid","_fails","_bylos","_fajlovi","_fitxategiak",".swf",".aspx")
    foreach ($ending in $badendings){
        if($LocalFile.Name.EndsWith($ending) -eq $True){
            $outstring = "ERROR| [$($LocalFile.FullName)] will be skipped, files cannot end or start with $ending`n"
            ac $detaillogpath $outstring
            $job1VARS.ERRORCount++ 
            $filecheck = $False                  
        }
    }
    if($LocalFile.Name.StartsWith("_") -eq $True){
        $outstring = "WARNING| underscore first character in [$($LocalFile.FullName)], item will be copied normally but will be hidden in destination.`n"
        ac $verifylogpath $outstring
        $job1VARS.WarningCount++                   
    }
    if($LocalFile.Name.EndsWith(".") -eq $True -or $LocalFile.Name.StartsWith(".") -eq $True){
        $outstring = "ERROR| [$($LocalFile.FullName)] will be skipped, folders or files cannot end or start with a period character.`n"
        ac $verifylogpath $outstring
        $filecheck = $False
        $job1VARS.ERRORCount++                   
    }
    <# /FILENAME CORRECTION MECHANISM #>
    $fileUrl = $FolderRelativeUrl + "/" + $filename
    
    if($fileUrl.Length -gt 250){
        ac $detaillogpath "ERROR| file path or name over 250 characters [$fileUrl], file was skipped!`n"
        $filecheck = $False
        $job1VARS.ERRORCount++
    }
    if($LocalFile.Length -gt 2047MB){
        ac $detaillogpath "WARNING| file is over 2GB in size [$fileUrl], file may fail!`n"
        $job1VARS.WarningCount++  
    }
    $badchars = ':,*,?,",<,>,|,#,{,},%,~,&'
    foreach($e in $badchars.Split(',')) { 
        if($fileUrl.Contains($e)){
            $fileUrl = $fileUrl.Replace($e,"")
            ac $detaillogpath "WARNING| illegal filename [$($fileUrl)], $e character removed automatically`n"
            $job1VARS.WarningCount++
        }
    }
    if($filecheck -eq $True){
        ac $detaillogpath "NOTICE| [$($LocalFile.FullName)] uploading to: $fileUrl`n"
        $job1VARS.currentfile = $LocalFile.FullName
        <# UPLOAD! #>
        try{
            [Microsoft.SharePoint.Client.File]::SaveBinaryDirect($Web.Context, $fileUrl, $LocalFile.OpenRead(), $true)
            <# Set original file date, @thanks to Rob Bosch #>
            [Microsoft.SharePoint.Client.File] $newfile = $Web.GetFileByServerRelativeUrl($fileUrl)
            $web.context.Load($newfile)
            $web.context.ExecuteQuery
            $newfile.Checkout()
            $item = $newfile.ListItemAllFields
            $item["Created"] = $LocalFile.CreationTime
            $item["Modified"] = $LocalFile.LastWriteTime
            $item.Update()
            $item.File.CheckIn("", [Microsoft.SharePoint.Client.CheckinType]::OverwriteCheckin)
            $context.ExecuteQuery()
        }catch{
            $job1VARS.ERRORCount++
            $err = $Error[0]|format-list -force
            ac $detaillogpath "ERROR| issue uploading: [$($LocalFile.FullName)] to : $fileUrl, errors: $($Error[0]) `n$($err)"
        }

    }

}
 
 
 
 
function Upload-Files()
{
 
Param(
  [Parameter(Mandatory=$True)]
  [String]$Url,
 
  [Parameter(Mandatory=$False)]
  [String]$UserName,
 
  [Parameter(Mandatory=$False)]
  [String]$Password, 
 
  [Parameter(Mandatory=$True)]
  [String]$TargetListTitle,
 
  [Parameter(Mandatory=$True)]
  [String]$SourceFolderPath
 
)


    $Context = New-Object Microsoft.SharePoint.Client.ClientContext($Url)
    $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($job1VARS.UserName,$job1VARS.SecurePassword)
    $Context.RequestTimeout = 16384000
    $Context.Credentials = $Credentials
    $web = $Context.Web 
    $Context.Load($web)
    $list = $web.Lists.GetByTitle($TargetListTitle);
    $Context.Load($list.RootFolder)
    try{
        $Context.ExecuteQuery()
    }catch{
        ac $detaillogpath "Error connecting to the document library you specified! Document library name: $($TargetListTitle)"
        $OUTPUT= [System.Windows.Forms.MessageBox]::Show("The document library you specified does not exist!", "O365Uploader" , 0)
        $job1VARS.PERCENT_DONE = 100
        $job1VARS.Trigger = 1
        $job1VARS.ERRORCount = 9999999
        Exit
    }
    $countkbs = 0
    Get-ChildItem $SourceFolderPath -Recurse | % {
        $countkbs += $_.Length
        $percent = ($countkbs / $job1VARS.total_files_size) *100
        
       if ($_.PSIsContainer -eq $True) {
          $folderUrl = $_.FullName.Replace($SourceFolderPath,"").Replace("\","/")   
          if($folderUrl) {
             Ensure-Folder -Web $web -ParentFolder $list.RootFolder -FolderUrl $folderUrl
          }  
       }
       
       else{
          $folderRelativeUrl = $list.RootFolder.ServerRelativeUrl + $_.DirectoryName.Replace($SourceFolderPath,"").Replace("\","/")  
          Upload-File -Web $web -FolderRelativeUrl $folderRelativeUrl -LocalFile $_ 
       }
       $job1VARS.PERCENT_DONE = $percent
    }
}
Upload-Files -Url $job1VARS.iURL -TargetListTitle $job1VARS.iRemoteFolder -SourceFolderPath $job1VARS.iLocalFolder
$job1VARS.PERCENT_DONE = 100
$job1VARS.Trigger = 1
ac $detaillogpath "-----$(Get-Date) Session END-----`n"