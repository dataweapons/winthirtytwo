########
#O365Uploader v0.7
#Copyright:     Free to use, please leave this header intact
#Author:        Jos Lieben (OGD)
#Company:       OGD (http://www.ogd.nl)
#Script help:   http://www.liebensraum.nl
#Purpose:       This script uploads a folder structure to Sharepoint Online or Onedrive for Business and checks the source folder for compatibility
########
#todo: 
########
#Requirements:
########
<#
Powershell 4 (download link)
.NET 4.5 (download link)
Sharepoint Server 2013 Client Components
run �Set-Executionpolicy Unrestricted� in an elevated powershell window
Windows 7+ or Windows Server 2008+
#>

########
#Changelog:
########
#V0.6: Additional checks and better logging, expected time left to finish upload
#V0.7: Added original file creation date (Thanks Rob)

$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
#Check of het script elevated it
If (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")){   
    $arguments = "& '" + $myinvocation.mycommand.definition + "'"
    Start-Process powershell -Verb runAs -ArgumentList $arguments
    Break
}

#laden van GUI
cd $scriptPath

try{
    Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase,system.windows.forms
} catch {
    $OUTPUT= [System.Windows.Forms.MessageBox]::Show("Failed to load Windows Presentation Framework assemblies, install .NET 4 or higher", "O365Uploader" , 0)
    Throw "Failed to load Windows Presentation Framework assemblies, install .NET 4 or higher"
}
try{
    Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\15\ISAPI\Microsoft.SharePoint.Client.dll"
    Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\15\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
} catch {
    $OUTPUT= [System.Windows.Forms.MessageBox]::Show("Please install the Sharepoint Extensions first", "O365Uploader" , 0)
    Throw "Failed to load Sharepoint Extensions, please install the Sharepoint 2013 Client Components "
}

$guiVARS = [hashtable]::Synchronized(@{})
$guiRunspace =[runspacefactory]::CreateRunspace()
$guiRunspace.ApartmentState = "STA"
$guiRunspace.ThreadOptions = "ReuseThread"          
$guiRunspace.Open()
$guiRunspace.SessionStateProxy.SetVariable("guiVARS",$guiVARS)  
        
$psGUIjob = [PowerShell]::Create().AddScript({   
    [xml]$xaml = @"
    <Window
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="O365Uploader v0.7 by Jos Lieben @ liebensraum.nl" Height="256.866" Width="788.881" WindowStartupLocation="CenterScreen" Background="#FFE7E7E7">
     <Window.TaskbarItemInfo>
        <TaskbarItemInfo Description="ss"/>
    </Window.TaskbarItemInfo>
        <Grid Margin="0,0,0.4,0" Height="213" VerticalAlignment="Top">
            <Label Content="O365 Folder Upload Tool" HorizontalAlignment="Left" Margin="10,10,0,0" VerticalAlignment="Top" FontSize="18"/>
            <Label Content="Note: this tool works for any Sharepoint (incl. Office 365) or OneDrive Document Library" HorizontalAlignment="Left" Margin="10,30,0,0" VerticalAlignment="Top" FontSize="9"/>
            <TextBox Name="iURL" HorizontalAlignment="Left" Height="30" Margin="10,49,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="254"/>
            <Label Content="Server URL (bijv https://ogd.sharepoint.com)" HorizontalAlignment="Left" Height="30" Margin="282,49,0,0" VerticalAlignment="Top" Width="400"/>
            <TextBox Name="iRemoteFolder" Text="Documents" HorizontalAlignment="Left" Height="30" Margin="10,84,0,0" TextWrapping="Wrap"  VerticalAlignment="Top" Width="254"/>
            <Label Content="Document library name" HorizontalAlignment="Left" Height="30" Margin="282,84,0,0" VerticalAlignment="Top" Width="400"/>
            <Button Name="iBrowse" Content="Select source folder" HorizontalAlignment="Left" Margin="282,119,0,0" VerticalAlignment="Top" Width="136" Height="30" Background="#FFFFFF"/>
            <Label Name="iProgress" Content="" HorizontalAlignment="Left" Height="30" Margin="530,145,0,0" VerticalAlignment="Top" Width="230"/>
            <TextBox Name="iLocaLFolder" HorizontalAlignment="Left" Height="30" Margin="10,119,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="254"/>
            <Button Name="iUpload" Content="Start upload" HorizontalAlignment="Left" Margin="451,167,0,0" VerticalAlignment="Top" Width="321" Height="36" Background="#FFFFFF"/>
            <ProgressBar Name="iBar" HorizontalAlignment="Left" Height="36" Margin="10,167,0,0" VerticalAlignment="Top" Width="436" Background="#FFFFFF"/>
        </Grid> 
    </Window>
"@


    $reader=(New-Object System.Xml.XmlNodeReader $xaml)
    $guiVARS.Window=[Windows.Markup.XamlReader]::Load( $reader )
    $xaml.SelectNodes("//*[@Name]") | %{
        $varname = $_.Name
        $guiVARS.$varname = $guiVARS.Window.FindName($varname)
        $guiVARS.$varname.Dispatcher.Invoke("Render", [Windows.Input.InputEventHandler] {$guiVARS.$varname.UpdateLayout()}, $null, $null)
    }
    $guiVARS.iBrowse.add_Click({
        $FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
        [void]$FolderBrowser.ShowDialog()
        $guiVARS.iLocalFolder.Text = $FolderBrowser.SelectedPath
        $OUTPUT= [System.Windows.Forms.MessageBox]::Show("Do you wish to verify the source folder first? This will check all file and folder names for illegal characters and other potential issues.", "Verify" , 4)
        if($OUTPUT -eq "YES"){
            $guiVARS.Verify = 1
            $guiVARS.iLocalFolderString = $guiVARS.iLocalFolder.Text
            $guiVARS.iURLString = $guiVARS.iURL.Text
            $guiVARS.iRemoteFolderString = $guiVARS.iRemoteFolder.Text
        }
    })
    $guiVARS.iUpload.add_Click({
        $OUTPUT= [System.Windows.Forms.MessageBox]::Show("Any files in this library with the same name will be overwritten, continue?", "Warning" , 4)
        if($guiVARS.iLocalFolder.Text.Length -gt 1 -and $guiVARS.iRemoteFolder.Text.Length -gt 1 -and $guiVARS.iURL.Text.Length -gt 5 -and $OUTPUT -eq "YES"){
            $guiVARS.iUpload.IsEnabled = $False
            $guiVARS.iUpload.Content = "Working..."
            $guiVARS.Trigger = 1
            $guiVARS.iLocalFolderString = $guiVARS.iLocalFolder.Text
            $guiVARS.iURLString = $guiVARS.iURL.Text
            $guiVARS.iRemoteFolderString = $guiVARS.iRemoteFolder.Text
        }else{
            $guiVARS.iLocalFolder.Text = "???"
            $guiVARS.iURL.Text = "???"
            $guiVARS.iRemoteFolder.Text = "???"
        }       
    })
    $guiVARS.Window.ShowDialog() | Out-Null
})
$psGUIjob.Runspace = $guiRunspace
$guiHandle = $psGUIjob.BeginInvoke()
Write-Host "Please wait..."
$global:starttime = Get-Date

#job monitor
Do {
    Start-Sleep -Milliseconds 500
    ##JOB STATES
    #0: uninitialized
    #1: initializing
    #2: running
    #3: done

    #JOB: Verify source folder first
    if($guiVARS.Verify -eq 1){
        Write-Host "Analyzing source folder..."
        $verifylogpath = $env:temp+"\SharePointUploaderDetailedVerificationLog"+$guiVARS.iRemoteFolderString+".log"
        ac $verifylogpath "-----$(Get-Date) Session Verificationlog-----`n"
        $remoteBasePathLength = $guiVARS.iRemoteFolderString.Length + $guiVARS.iURLString.Length + 2
        $localBasePathLength = $guiVARS.iLocalFolderString.Length

        $total_files_size = 0
        $total_files = 0
        $total_folders = 0
        $errors = 0
        $warnings = 0
        foreach($t in Get-ChildItem $guiVARS.iLocalFolderString -Recurse){
            $badchars = ':,*,?,",<,>,|,#,{,},%,~,&'
            foreach($e in $badchars.Split(',')) { 
                if($t.Name.Contains($e)){
                    $outstring = "WARNING| illegal character in [$($t.FullName)], $e character will be removed automatically`n"
                    ac $verifylogpath $outstring
                    Write-Host $outstring
                    $warnings++
                }
            }
            if($t.FullName.Length - $localBasePathLength + $remoteBasePathLength -gt 250){
                $outstring = "ERROR| file path over 250 characters [$($t.FullName)], this item will be skipped!`n"
                ac $verifylogpath $outstring
                Write-Host $outstring
                $errors++
            }
            if($t.Name.StartsWith("_") -eq $True){
                $outstring = "WARNING| underscore first character in [$($t.FullName)], item will be copied normally but will be hidden in destination.`n"
                ac $verifylogpath $outstring
                Write-Host $outstring
                $warnings++                    
            }
            if($t.Name.EndsWith(".") -eq $True -or $t.Name.StartsWith(".") -eq $True){
                $outstring = "ERROR| [$($t.FullName)] will be skipped, folders or files cannot end or start with a period character.`n"
                ac $verifylogpath $outstring
                Write-Host $outstring
                $errors++                    
            }
            #FILESPECIFIC
            if ($t.PSIsContainer -eq $False){
                $total_files_size += $t.length
                $total_files++
                
                if($t.Length -gt 2047MB){
                    $outstring = "ERROR| file size over 2GB [$($t.FullName)], file may be skipped if your tenant has not been upgraded yet!`n"
                    ac $verifylogpath $outstring
                    Write-Host $outstring
                    $errors++
                }
                $badendings = @(".files","_files","-Dateien","_fichiers","_bestanden","_file","_archivos","-filer","_tiedostot","_pliki","_soubory","_elemei","_ficheiros","_arquivos","_dosyalar","_datoteke","_fitxers","_failid","_fails","_bylos","_fajlovi","_fitxategiak")
                foreach ($ending in $badendings){
                    if($t.Name.EndsWith($ending) -eq $True){
                        $outstring = "ERROR| [$($t.FullName)] will be skipped, files cannot end or start with $ending`n"
                        ac $verifylogpath $outstring
                        Write-Host $outstring
                        $errors++                    
                    }
                }
            }else{
            #FOLDERSPECIFIC
                $total_folders++
            }
        }
        $total_items = $total_files+$total_folders;
        $total_files_sizeMB = $total_files_size/1048576
        if($total_items -gt 5000) {
            Write-Host ("Warning: over 5000 items, please read http://sharepoint.stackexchange.com/questions/105937/overcoming-5000-file-document-library-limits")
        }
        Write-Host ("Total size: "+$total_files_sizeMB+"MB")
        Write-Host ("Total unresolvable issues found: "+$errors)
        Write-Host ("Total auto resolvable issues found: "+$warnings)
        Write-Host ("Check the log file at "+$verifylogpath+" to fix any issues")
        $guiVARS.Verify = 2
    }

    #JOB: Upload everything
    if($guiVARS.Trigger -eq 1){
        $credential = Get-Credential -Message "Please enter your Office 365 Credentials"
        $UserName = $credential.GetNetworkCredential().UserName
        $SecurePassword = $credential.GetNetworkCredential().Password | ConvertTo-SecureString -AsPlainText -Force
        Write-Host "Analyzing source folder, counting files and data for progress indicator, this may take a while....."
        $total_files_size = 0;
        $total_files = 0;
        $total_folders = 0;
        foreach($t in Get-ChildItem $guiVARS.iLocalFolderString -Recurse){
            if ($t.PSIsContainer -eq $False){
                if($t.Length -lt 2047MB){
                    $total_files_size += $t.length
                }
                $total_files++
            }else{
                $total_folders++
            }
        }
        $total_items = $total_files+$total_folders;
        $total_files_sizeMB = $total_files_size/1048576
        #open new thread for the job to run in
        $job1VARS = [hashtable]::Synchronized(@{})
        $job1Runspace =[runspacefactory]::CreateRunspace()
        $job1Runspace.ApartmentState = "STA"
        $job1Runspace.ThreadOptions = "ReuseThread"          
        $job1Runspace.Open()
        $job1Runspace.SessionStateProxy.SetVariable("job1VARS",$job1VARS)  
        $OFS = "`r`n"
        $job1Code = [ScriptBlock]::Create($(Get-Content 'uploader_job_v0.7.ps1'))
        Remove-Variable OFS
        Write-Host (""+$total_files+" files")
        Write-Host (""+$total_folders+" folders")
        Write-Host "$(Get-Date): Logging in to Office 365"
        

        #stel variabelen in voor de taak
        $job1VARS.iLocalFolder = $guiVARS.iLocalFolderString
        $job1VARS.iURL = $guiVARS.iURLstring
        $job1VARS.iRemoteFolder = $guiVARS.iRemoteFolderString
        $job1VARS.UserName = $UserName
        $job1VARS.SecurePassword = $SecurePassword
        $job1VARS.total_files_size = $total_files_size
        if($UserName.Length -gt 3 -and $SecurePassword.Length -gt 3){
            Write-Host ("Local folder: "+$job1VARS.iLocalFolder)
            Write-Host ("Total items (recursive): "+$total_items)
            Write-Host ("Total size: "+"{0:N3}" -f $total_files_sizeMB+" MB")
            Write-Host ("Remote folder: "+$job1VARS.iRemoteFolder)
            Write-Host ("Server location: "+$job1VARS.iURL)
            Write-Host ("Job running as: "+$job1VARS.UserName)
            Write-Host "Upload Thread Started"
            $psUploadJob = [PowerShell]::Create().AddScript($job1Code)
            $psUploadJob.Runspace = $job1Runspace
            $uploadJobHandle = $psUploadJob.BeginInvoke()         
            $guiVARS.Trigger = 2
        }else{
            $guiVARS.Trigger = 0
            Write-Host "You did not enter your credentials"
            $guiVARS.iUpload.Dispatcher.invoke("Normal",[action]{$guiVARS.iUpload.IsEnabled=$True})
            $guiVARS.iUpload.Dispatcher.invoke("Normal",[action]{$guiVARS.iUpload.Content="Uploaden"})
        }

    }
    if($guiVARS.Trigger -eq 2){
        if($job1VARS.PERCENT_DONE -gt 0){        
            $runtime = ((Get-Date) - $starttime).TotalSeconds
            $timeleft = ((100/$job1VARS.PERCENT_DONE)*$runtime)-$runtime
            $ts =  [timespan]::fromseconds($timeleft)
            
            $percent_display = "@ "+"{0:N3}" -f $job1VARS.PERCENT_DONE+"% done, $("{0:hh\:mm\:ss}" -f $ts) time remaining"
        }else{
            $percent_display = "Connecting and creating folders in target library...."  
            Write-Host "Connecting and provisioning folders in target library"
        }
        
        if($job1VARS.currentfile.length -gt 1 -and $job1VARS.currentfile -ne $tempcurrentfile){
            Write-Host ("Working on file: "+$job1VARS.currentfile)
            $tempcurrentfile = $job1VARS.currentfile
        }
        $guiVARS.iProgress.Dispatcher.invoke("Normal",[action]{$guiVARS.iProgress.Content=$percent_display})
        $guiVARS.iBar.Dispatcher.invoke("Normal",[action]{$guiVARS.iBar.value=$job1VARS.PERCENT_DONE})
    }
    #upload job is done
    if($job1VARS.Trigger -eq 1){
        $guiVARS.Trigger = 3
    }
    #summarize and reset jobs to initial state
    if($guiVARS.Trigger -eq 3){
        $guiVARS.Trigger = 0
        $job1VARS.Trigger = 0
        $guiVARS.iUpload.Dispatcher.invoke("Normal",[action]{$guiVARS.iUpload.IsEnabled=$True})
        $guiVARS.iUpload.Dispatcher.invoke("Normal",[action]{$guiVARS.iUpload.Content="Upload klaar"})
        $guiVARS.iProgress.Dispatcher.invoke("Normal",[action]{$guiVARS.iProgress.Content="100% done"})
        $guiVARS.iBar.Dispatcher.invoke("Normal",[action]{$guiVARS.iBar.value=100})
        Write-Host ("JOB SUMMARY:")
        Write-Host ("Total Items: "+$total_items)
        Write-Host ("Autocorrected Items: "+$job1VARS.WarningCount)
        Write-Host ("Failed Items: "+$job1VARS.ERRORCount)
        Write-Host ("Detailed log file written to: "+$env:temp+"\SharePointUploaderDetailedLog"+$job1VARS.iRemoteFolder+".log")

    }
}Until($guihandle.IsCompleted -eq $True)
