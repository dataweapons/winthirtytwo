Instructions:

Do not run from a network drive
Install Powershell 4, .NET 4.5 and the Sharepoint Server 2013 Client Components
Run Set-Executionpolicy Unrestricted in an elevated Window

For the Server URL, include the site and subsite names, for example:

https://ogd-my.sharepoint.com/personal/jos_lieben_ogd_nl

For the library name, use, for example, Documents